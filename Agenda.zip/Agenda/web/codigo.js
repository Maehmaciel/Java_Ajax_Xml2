function criarAjaxGet(servlet, funcao)
{
    ajax = new XMLHttpRequest();
    ajax.onreadystatechange = funcao;
    ajax.open("GET", servlet, true);
    ajax.send();
}

function criarAjaxDelete(servlet, funcao)
{
    ajax = new XMLHttpRequest();
    ajax.onreadystatechange = funcao;
    ajax.open("GET", servlet, true);
    ajax.send();
}


function criarAjaxPost(servlet, recurso)
{


    ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function () {

        if (this.readyState == 4 && this.status == 200)
        {
            criarAjaxGet("controle", mostrar)
        }
    }
    ajax.open("POST", servlet, true);
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send("dados=" + recurso);
    console.log(recurso)
}

function apaga(codigo){
    //criarAjaxDelete(servlet, funcao)
    console.log(document.getElementById(codigo))
    xml="<root></root>"
    parser= new DOMParser()
    doc=parser.parseFromString(xml,"text/xml")
    raiz = doc.documentElement;
    x = doc.getElementsByTagName("root")[0]
    pessoa = doc.createElement("Pessoa");
    acaoXml = doc.createElement("Excluir");
    acaoTxtXml = doc.createTextNode(codigo);
    acaoXml.appendChild(acaoTxtXml)
    pessoa.appendChild(acaoXml)
     x.appendChild(pessoa)
    recurso = x.innerHTML
    console.log(recurso)
}

function edita(codigo){
    console.log(document.getElementById(codigo))
    xml="<root></root>"
    parser= new DOMParser()
    doc=parser.parseFromString(xml,"text/xml")
    raiz = doc.documentElement;
    x = doc.getElementsByTagName("root")[0]
    pessoa = doc.createElement("Pessoa");
    acaoXml = doc.createElement("Editar");
    acaoTxtXml = doc.createTextNode(codigo);
    acaoXml.appendChild(acaoTxtXml)
    pessoa.appendChild(acaoXml)
     x.appendChild(pessoa)
    recurso = x.innerHTML
    console.log(recurso)
}

function mostrar()
{
    index=document.getElementById('la')
    index.innerHTML=null
    if (this.readyState == 4 && this.status == 200)
    {
        doc = this.responseXML;

        raiz = doc.documentElement;
        texto = "";
        filhos = raiz.childNodes;
        tam = filhos.length;
       
        for (i = 0; i < tam; i++)
        {
            
                if (filhos[i].nodeType == 1)
                {
                    
                    li=document.createElement('li')
                    li.innerHTML=filhos[i].children[1].childNodes[0].nodeValue + ": " + filhos[i].children[2].childNodes[0].nodeValue
                    
                    apagar=document.createElement('button')
                            apagar.innerHTML='apagar'
                    editar=document.createElement('button')
                            editar.innerHTML='Editar'
                    apagar.setAttribute("onclick",`apaga('${filhos[i].children[0].childNodes[0].nodeValue}')`)
                    editar.setAttribute("onclick",`edita('${filhos[i].children[0].childNodes[0].nodeValue}')`)
                    
                    
                    li.appendChild(apagar)
                    li.appendChild(editar)
                    li.id=filhos[i].children[0].childNodes[0].nodeValue
                    li.innerHTML+="<hr>"
                   
                   index.appendChild(li)
                
                }
            

        }
    }
}


function criarPessoa()
{
    xml="<root></root>"
    parser= new DOMParser()
    doc=parser.parseFromString(xml,"text/xml")
    raiz = doc.documentElement;
    x = doc.getElementsByTagName("root")[0]

    nome = document.getElementById('nome').value;
    telefone = document.getElementById('telefone').value;

    pessoa = doc.createElement("Pessoa");
    acaoXml = doc.createElement("acao");
    acaoTxtXml = doc.createTextNode("Inserir");
    acaoXml.appendChild(acaoTxtXml)
    pessoa.appendChild(acaoXml)
    nomeXml = doc.createElement("nome");
    nomeTxtXml = doc.createTextNode(nome);
    nomeXml.appendChild(nomeTxtXml)
    pessoa.appendChild(nomeXml)
    telefoneXml = doc.createElement("telefone");
    telefoneTxtXml = doc.createTextNode(telefone);
    telefoneXml.appendChild(telefoneTxtXml);
    pessoa.appendChild(telefoneXml)


    x.appendChild(pessoa)
    recurso = x.innerHTML
    criarAjaxPost("controle",recurso)
}



